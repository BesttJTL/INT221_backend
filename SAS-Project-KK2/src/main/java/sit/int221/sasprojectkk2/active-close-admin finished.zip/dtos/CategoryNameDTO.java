package sit.int221.sasprojectkk2.dtos;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CategoryNameDTO {
    private String categoryName;
}
