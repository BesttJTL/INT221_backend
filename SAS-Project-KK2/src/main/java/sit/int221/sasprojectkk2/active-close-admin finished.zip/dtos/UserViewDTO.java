package sit.int221.sasprojectkk2.dtos;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserViewDTO {
    private String announcementTitle;
    private String announcementCategory;
}
