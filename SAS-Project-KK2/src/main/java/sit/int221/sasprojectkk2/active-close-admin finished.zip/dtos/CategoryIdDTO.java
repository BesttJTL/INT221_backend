package sit.int221.sasprojectkk2.dtos;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CategoryIdDTO {
    private Integer categoryId;
}
