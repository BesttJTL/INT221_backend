package sit.int221.sasprojectkk2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SasProjectKk2Application {

    public static void main(String[] args) {
        SpringApplication.run(SasProjectKk2Application.class, args);
    }

}
